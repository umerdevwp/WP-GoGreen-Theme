<?php
/*****************************************
*   SHORTCODE FUNCTIONS
/*****************************************/
/* Register body styles */
function wyde_add_body_style($handle, $src){
    global $wyde_body_stylesheets;
    if( !$wyde_body_stylesheets ){
        $wyde_body_stylesheets = array();
    }

    $wyde_body_stylesheets[$handle] = $src;    
}

/* Add shortcode settings */
function wyde_add_settings( $shortcode, $settings = array() ) {
    global $wyde_shortcodes_settings; 

    if( !$wyde_shortcodes_settings ){
        $wyde_shortcodes_settings = array();
    }

    $wyde_shortcodes_settings[$shortcode] = $settings;
}

/* Localize shortcodes settings data*/
function wyde_render_shortcode_settings( $handle ){
    global $wyde_shortcodes_settings;   
    $shortcodes_settings = apply_filters('wyde_shortcodes_settings', $wyde_shortcodes_settings );
    wp_localize_script( $handle, 'wyde_shortcodes_settings', $shortcodes_settings);
}

/* Is Visual Composer active */
function wyde_is_vc_active(){
    if( defined( 'WPB_VC_VERSION' ) ){
        return true;
    }else{
        return false;
    }
}

/* Is Revolution Slider active */
function wyde_is_revslider_active(){
    $is_active = class_exists( 'RevSlider' );
    return apply_filters('wyde_is_revslider_active',  $is_active);
}

/* Get revolution sliders */
function wyde_get_revsliders(){

    $sliders = array();

    if( wyde_is_revslider_active() ){

        $rev_slider = new RevSlider();
        $arrSliders = $rev_slider->getArrSliders();
        
        if ( $arrSliders ) {
            foreach ( $arrSliders as $rev_slider ) {
                $sliders[ $rev_slider->getTitle() ] = $rev_slider->getAlias();
            }
        } else {
            $sliders[ __( 'No sliders found', 'wyde-core' ) ] = 0;
        }

    }

    return apply_filters('wyde_get_revsliders', $sliders);
}

function wyde_add_async_attribute($tag, $handle) {   

    $scripts = array('googlemaps');

    foreach($scripts as $script) {
        if ($script === $handle) {
            return str_replace(' src', ' async defer src', $tag);
        }
    }

    return $tag;
}
add_filter( 'script_loader_tag', 'wyde_add_async_attribute', 10, 2);


/* Register tinymce editor buttons */
function wyde_editor_add_buttons( $buttons ) {

    //insert dropcap button
    array_splice($buttons, 3, 0, 'dropcap');
    
    //insert hilight button
    array_splice($buttons, 4, 0, 'highlight');

    //Remove buttons
    /*$removes = array('revslider');

    //Find the array key and then unset
    foreach( $removes as $remove){
      if ( ( $key = array_search($remove, $buttons) ) !== false )   unset($buttons[$key]);
    }*/

    return $buttons;
}

/* Register Wyde button plugins */
function wyde_editor_register_buttons( $plugin_array ) {
    $plugin_array['wydeEditor'] = WYDE_PLUGIN_URI. 'shortcodes/js/editor-plugin.js';
    return $plugin_array;
}

/* Add Wyde buttons to tinymce editor */
function wyde_editor_init(){    
    add_filter( 'mce_buttons', 'wyde_editor_add_buttons', 1000 );
    add_filter( 'mce_external_plugins', 'wyde_editor_register_buttons' );
}

/* Add Google font links into body tag */
function wyde_body_stylesheets(){ 
    global $wyde_body_stylesheets;           
    $body_stylesheets = apply_filters('wyde_body_stylesheets', $wyde_body_stylesheets);
    /* Add stylesheets inside body tag */
    if( is_array($body_stylesheets) ){
        foreach ($body_stylesheets as $key => $value) {
            echo sprintf('<link id="%s" href="%s" rel="stylesheet" property="stylesheet" type="text/css" media="all" />', esc_attr($key), esc_url($value) );
        }
    }
}
add_action( 'wp_footer', 'wyde_body_stylesheets' );


function wyde_get_animations(){

    /* Animate.css v 3.5.1 */
    $animations =  array(
        ''                                      => __('No Animation', 'wyde-core'),
        'bounce'                                => __('Bounce', 'wyde-core'),
        'bounceIn'                              => __('Bounce In', 'wyde-core'),
        'bounceInUp'                            => __('Bounce In Up', 'wyde-core'),
        'bounceInDown'                          => __('Bounce In Down', 'wyde-core'),
        'bounceInLeft'                          => __('Bounce In Left', 'wyde-core'),
        'bounceInRight'                         => __('Bounce In Right', 'wyde-core'),
        'fadeIn'                                => __('Fade In', 'wyde-core'),
        'fadeInUp'                              => __('Fade In Up', 'wyde-core'),
        'fadeInDown'                            => __('Fade In Down', 'wyde-core'),
        'fadeInLeft'                            => __('Fade In Left', 'wyde-core'),
        'fadeInRight'                           => __('Fade In Right', 'wyde-core'),
        'fadeInUpBig'                           => __('Fade In Up Long', 'wyde-core'),
        'fadeInDownBig'                         => __('Fade In Down Long', 'wyde-core'),
        'fadeInLeftBig'                         => __('Fade In Left Long', 'wyde-core'),
        'fadeInRightBig'                        => __('Fade In Right Long', 'wyde-core'),
        'flipInX'                               => __('Flip In X', 'wyde-core'),
        'flipInY'                               => __('Flip In Y', 'wyde-core'),
        'lightSpeedIn'                          => __('Light Speed In', 'wyde-core'),
        'pulse'                                 => __('Pulse', 'wyde-core'),
        'rollIn'                                => __('Roll In', 'wyde-core'),
        'rotateIn'                              => __('Rotate In', 'wyde-core'),
        'slideInUp'                             => __('Slide In Up', 'wyde-core'),
        'slideInDown'                           => __('Slide In Down', 'wyde-core'),
        'slideInLeft'                           => __('Slide In Left', 'wyde-core'),
        'slideInRight'                          => __('Slide In Right', 'wyde-core'),
        'swing'                                 => __('Swing', 'wyde-core'),
        'tada'                                  => __('Tada', 'wyde-core'),
        'zoomIn'                                => __('Zoom In', 'wyde-core'),
        'zoomInUp'                              => __('Zoom In Up', 'wyde-core'),
        'zoomInDown'                            => __('Zoom In Down', 'wyde-core'),
        'zoomInLeft'                            => __('Zoom In Left', 'wyde-core'),
        'zoomInRight'                           => __('Zoom In Right', 'wyde-core'),
    );

    return apply_filters('wyde_get_animations', $animations);
}


function wyde_animation_field($settings, $value) {   
            
    $html ='<div class="wyde-animation">';
    $html .='<div class="animation-field">';
    $html .= sprintf('<select name="%1$s" class="wpb_vc_param_value %1$s %2$s_field">', esc_attr( $settings['param_name'] ), esc_attr( $settings['type'] ));

    $animations  = wyde_get_animations();

    foreach($animations as $key => $text){
        $html .= sprintf('<option value="%s" %s>%s</option>', esc_attr( $key ), ( $value == $key ? ' selected' : '' ), esc_html( $text ) );
    }
    
    $html .= '</select>';
    $html .= '</div>';
    $html .= '<div class="animation-preview"><span>Animation</span></div>';
    $html .= '</div>';

    return $html;
}


function wyde_gmaps_field($settings, $value) {

    $html ='<div class="wyde-gmaps">';
    $html .='<div class="wyde-gmaps-settings">';
    $html .= sprintf('<input name="%1$s" class="wpb_vc_param_value %1$s %2$s_field" type="hidden" value="%3$s" />', esc_attr( $settings['param_name'] ), esc_attr( $settings['type'] ), esc_attr( $value ));
    $html .= '</div>';
    $html .= '<div class="vc_column vc_clearfix">';
    $html .= '<div class="gmaps-canvas" style="height:500px;margin-top:10px;"></div>';
    $html .= '</div>';
    $html .= '</div>';

    return $html;

}