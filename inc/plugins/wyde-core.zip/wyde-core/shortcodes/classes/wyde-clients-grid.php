<?php
/* Clients Grid
---------------------------------------------------------- */
class WPBakeryShortCode_Wyde_Clients_Grid extends WPBakeryShortCode {
}

vc_map( array(
    'name' => __('Clients Grid', 'wyde-core'),
    'description' => __('Client logos grid.', 'wyde-core'),
    'base' => 'wyde_clients_grid',
    'controls' => 'full',
    'icon' =>  'wyde-icon clients-grid-icon', 
    'weight'    => 900,
    'category' => __('Wyde', 'wyde-core'),
    'params' => array(
        array(
            'param_name' => 'images',
            'type' => 'attach_images',
            'heading' => __('Images', 'wyde-core'),                    
            'description' => __('Upload or select images from media library.', 'wyde-core')
        ),
        array(
            'param_name' => 'image_size',
	        'type' => 'dropdown',
	        'heading' => __( 'Image Size', 'wyde-core' ),			        
	        'value' => array(
		        __('Thumbnail', 'wyde-core' ) => 'thumbnail',
                __('Medium', 'wyde-core' ) => 'medium',
                __('Large', 'wyde-core' ) => 'large',
                __('Original', 'wyde-core' ) => 'full',
	        ),
	        'description' => __( 'Select image size.', 'wyde-core' )
        ),
        array(
            'param_name' => 'columns',
            'type' => 'dropdown',                   
            'heading' => __('Columns', 'wyde-core'),                    
            'value' => array( '2', '3', '4', '5', '6' ),
            'std' => '3',
            'description' => __('The number of columns to display the logos.', 'wyde-core')
        ),
        array(
            'param_name' => 'animation',
            'type' => 'wyde_animation',
            'heading' => __('Animation', 'wyde-core'),                    
            'description' => __('Select a CSS3 Animation that applies to this element.', 'wyde-core')
        ),
        array(
            'param_name' => 'animation_delay',
            'type' => 'textfield',                    
            'heading' => __('Animation Delay', 'wyde-core'),                 
            'description' => __('Defines when the animation will start (in seconds). Example: 0.5, 1, 2, ...', 'wyde-core'),
            'dependency' => array(
                'element' => 'animation',
                'not_empty' => true
            )
        ),
        array(
            'param_name' => 'el_class',
	        'type' => 'textfield',
	        'heading' => __( 'Extra CSS Class', 'wyde-core' ),			        
	        'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'wyde-core' )
        ),
    )
    
) );