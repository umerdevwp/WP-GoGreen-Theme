<?php
/* Instagram
---------------------------------------------------------- */
class WPBakeryShortCode_Wyde_Instagram extends WPBakeryShortCode {
}

vc_map( array(
    'name' => __( 'Instagram Feed', 'wyde-core' ),
    'base' => 'wyde_instagram',
    'icon' => 'wyde-icon instagram-icon',
    'weight'    => 900,
    'category' => __('Wyde', 'wyde-core'),
    'description' => __( 'Photos feed from Instagram account.', 'wyde-core' ),
    "params" => array(        
        array(
            'param_name' => 'title',
            'type' => 'textfield',
            'heading' => __( 'Title', 'wyde-core' ),            
            'admin_label' => true,
            'description' => __('Enter title text.', 'wyde-core')
        ),
        array(
            'param_name' => 'image_size',
            'type' => 'dropdown',
            'heading' => __( 'Image Size', 'wyde-core' ),        
            'admin_label' => true,          
            'value' => array(
                __('Small', 'wyde-core') => 'small', 
                __('Medium', 'wyde-core') => 'medium',
                __('Large', 'wyde-core') => 'big',
            ),
            'description' => __( 'Select image size.', 'wyde-core' ),
            'std' => 'medium'
        ),
        array(
            'param_name' => 'count',
            'type' => 'dropdown',
            'heading' => __( 'Number of photos', 'wyde-core' ),         
            'admin_label' => true,
            'value' => array( 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 ),
            'description' => __( 'Select number of photos to display.', 'wyde-core' )
        ),
        array(
            'param_name' => 'gallery_type',
            'type' => 'dropdown',
            'heading' => __( 'Gallery Type', 'wyde-core' ),        
            'admin_label' => true,          
            'value' => array(
                __('Grid (Without Space)', 'wyde-core') => 'grid', 
                __('Grid (With Space)', 'wyde-core') => 'grid w-space',
                __('Slider', 'wyde-core') => 'slider',
            ),
            'description' => __( 'Select gallery type.', 'wyde-core' )
        ),
        array(
            'param_name' => 'columns',
            'type' => 'dropdown',
            'heading' => __( 'Columns', 'wyde-core' ),          
            'value' => array( 2, 3, 4, 5, 6, 12 ),
            'description' => __( 'Select number of grid columns to display.', 'wyde-core' ),
            'std' => 4,
            'dependency' => array(
                'element' => 'gallery_type',
                'value' => array('grid', 'grid w-space')
            )
        ),
        array(
            'param_name' => 'visible_items',
            'type' => 'dropdown',
            'heading' => __('Visible Items', 'wyde-core'),                    
            'value' => array('auto', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'),
            'std' => '3',
            'description' => __('The maximum amount of items displayed at a time.', 'wyde-core'),
            'dependency' => array(
                'element' => 'gallery_type',
                'value' => array('slider')
            )
        ),
        array(
            'param_name' => 'transition',
            'type' => 'dropdown',
            'heading' => __('Transition', 'wyde-core'),                    
            'value' => array(
                __('Slide', 'wyde-core') => '', 
                __('Fade', 'wyde-core') => 'fade', 
            ),
            'description' => __('The maximum amount of items displayed at a time.', 'wyde-core'),
            'dependency' => array(
                'element' => 'visible_items',
                'value' => array('1')
            )
        ),
        array(
            'param_name' => 'show_navigation',
            'type' => 'checkbox',
            'heading' => __('Show Navigation', 'wyde-core'),                    
            'description' => __('Display "next" and "prev" buttons.', 'wyde-core'),
            'dependency' => array(
                'element' => 'gallery_type',
                'value' => array('slider')
            )
        ),
        array(
            'param_name' => 'show_pagination',
            'type' => 'checkbox',
            'heading' => __('Show Pagination', 'wyde-core'),                    
            'description' => __('Show pagination.', 'wyde-core'),
            'dependency' => array(
                'element' => 'gallery_type',
                'value' => array('slider')
            )
        ),
        array(
            'param_name' => 'loop',
            'type' => 'checkbox',
            'heading' => __('Loop', 'wyde-core'),                    
            'description' => __('Inifnity loop. Duplicate last and first items to get loop illusion.', 'wyde-core'),
            'dependency' => array(
                'element' => 'gallery_type',
                'value' => array('slider')
            )
        ),
        array(
            'param_name' => 'auto_play',
            'type' => 'checkbox',
            'heading' => __('Auto Play', 'wyde-core'),                    
            'description' => __('Auto play slide.', 'wyde-core'),
            'dependency' => array(
                'element' => 'gallery_type',
                'value' => array('slider')
            )
        ),
        array(
            'param_name' => 'speed',
            'type' => 'dropdown',
            'heading' => esc_html__('Speed', 'wyde-core'),                    
            'value' => array('1', '2', '3', '4', '5', '6', '7', '8', '9', '10'),
            'std' => '4',
            'description' => esc_html__('The amount of time between each slideshow interval (in seconds).', 'wyde-core'),
            'dependency' => array(
                'element' => 'auto_play',
                'value' => 'true'
            )
        ),
        array(
            'param_name' => 'el_class',
            'type' => 'textfield',
            'heading' => __( 'Extra CSS Class', 'wyde-core' ),          
            'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'wyde-core' )
        ),
    )
) );