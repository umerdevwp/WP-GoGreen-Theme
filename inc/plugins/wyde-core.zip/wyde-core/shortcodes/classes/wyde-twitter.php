<?php
/* Twitter Timeline
---------------------------------------------------------- */
class WPBakeryShortCode_Wyde_Twitter extends WPBakeryShortCode {
}

vc_map( array(
    'name' => __( 'Twitter Timeline', 'wyde-core' ),
    'base' => 'wyde_twitter',
    'icon' => 'wyde-icon twitter-icon',
    'weight'    => 900,
    'category' => __('Wyde', 'wyde-core'),
    'description' => __( 'Displays Twitter timeline.', 'wyde-core' ),
    "params" => array(        
        array(
            'param_name' => 'user_name',
            'type' => 'textfield',
            'heading' => __( 'User Name', 'wyde-core' ),            
            'admin_label' => true,
            'description' => __( 'A Twitter User Name.', 'wyde-core' )
        ),
        array(
            'param_name' => 'count',
            'type' => 'dropdown',
            'heading' => __( 'Number of tweets', 'wyde-core' ),         
            'admin_label' => true,
            'value' => array( 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 ),
            'description' => __( 'Select number of tweets to display.', 'wyde-core' ),
            'std'   => 5
        ),
        array(
            'param_name' => 'theme',
            'type' => 'dropdown',
            'heading' => __( 'Theme', 'wyde-core' ),        
            'admin_label' => true,          
            'value' => array(
                __('Light', 'wyde-core') => '', 
                __('Dark', 'wyde-core') => 'dark',
            ),
            'description' => __( 'Select Dark to display light text on a dark background.', 'wyde-core' ),
        ),
        array(
            'param_name' => 'transparent',
            'type' => 'checkbox',
            'heading' => __('Transparent Background', 'wyde-core'),                     
            'description' => __('Display transparent background.', 'wyde-core'),
            'value' => true              
        ),
        array(
            'param_name' => 'show_header',
            'type' => 'checkbox',
            'heading' => __('Show Header', 'wyde-core'),                     
            'description' => __('Show user profile photo and bio.', 'wyde-core')                
        ),
        array(
            'param_name' => 'show_scrollbar',
            'type' => 'checkbox',
            'heading' => __('Show Scrollbar', 'wyde-core'),               
            'description' => __('Show user profile photo and bio.', 'wyde-core')                
        ),
        array(
            'param_name' => 'show_border',
            'type' => 'checkbox',
            'heading' => __('Show Border', 'wyde-core'),              
            'description' => __('Show user profile photo and bio.', 'wyde-core')                
        ),
        array( 
            'param_name' => 'border_color', 
            'type' => 'colorpicker',
            'heading' => __('Border Color', 'wyde-core'),                    
            'description' => __('Select border color.', 'wyde-core'),
            'dependency' => array(
                'element' => 'show_border',
                'value' => 'true'
            )
        ),
        array(
            'param_name' => 'width',
            'type' => 'textfield',
            'heading' => __('Width', 'wyde-core'),            
            'value' => '',
            'description' => __('The pixel width of the widget. Leave blank to set as auto width.', 'wyde-core'),                
        ),
        array(
            'param_name' => 'height',
            'type' => 'textfield',
            'heading' => __('Height', 'wyde-core'),            
            'value' => '600',
            'description' => __('The pixel height of the widget.', 'wyde-core'),                
        ),
        array(
            'param_name' => 'el_class',
            'type' => 'textfield',
            'heading' => __( 'Extra CSS Class', 'wyde-core' ),          
            'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'wyde-core' )
        ),
    )
) );