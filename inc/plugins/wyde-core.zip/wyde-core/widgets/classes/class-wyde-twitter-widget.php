<?php
class Wyde_Widget_Twitter extends WP_Widget {

	function __construct() {
		parent::__construct(
            'w-twitter', 
            esc_html__('Wyde Twitter Timeline', 'wyde-core'), 
            array(
                'classname' => 'wyde_widget_twitter', 
                'description' => esc_html__('Displays Twitter timeline.', 'wyde-core')
            )
        );

	}

	function widget($args, $instance) {

        extract( $args );

		$title = apply_filters('widget_title', $instance['title']);
		$user_name = strip_tags( $instance['user_name'] );
		$count = $instance['count'];
		$theme =  $instance['theme'];
        $width =  $instance['width'];
        $height =  $instance['height'];
	
        $output = '';

        if($title) {
            $output = $before_title . esc_html( $title ) . $after_title;
        }
	
		$output .= do_shortcode( sprintf('[wyde_twitter user_name="%s" count="%s" theme="%s" width="%s" height="%s" show_border="0"]', 
            esc_attr( $user_name ), 
            intval( $count ), 
            esc_attr( $theme ),
            esc_attr( $width ),
            esc_attr( $height )
             ) );
		
		echo "{$before_widget}{$output}{$after_widget}";
	}

	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		
        $instance['title']			= $new_instance['title'];
		$instance['user_name'] 		= $new_instance['user_name'];
		$instance['count']          = $new_instance['count'];
        $instance['theme']          = $new_instance['theme'];
        $instance['width']          = $new_instance['width'];
        $instance['height']         = $new_instance['height'];		
        
		return $instance;
	}

	function form( $instance ) {
		
        // Set up the default form values.
		$defaults = array(
			'title'			=> esc_html__('Twitter Timeline', 'wyde-core'),
			'user_name'		=> '',
			'count'         => 9,
            'theme'     => '',
            'width'         => '',
            'height'         => 600,
		);


		/* Merge the user-selected arguments with the defaults. */
		$instance = wp_parse_args( (array) $instance, $defaults );
        
        ?>
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__('Title', 'wyde-core'); ?>:</label>
		    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
        </p>       

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'user_name' ) ); ?>"><?php echo esc_html__('User Name', 'wyde-core'); ?>:</label>
		    <input id="<?php echo esc_attr( $this->get_field_id( 'user_name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'user_name' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['user_name'] ); ?>" />            
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__('Theme', 'wyde-core'); ?>:</label>
            <select id="<?php echo esc_attr( $this->get_field_id( 'theme' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'theme' ) ); ?>">
                <?php
                $options = array( 
                    '' => __('Light', 'wyde-core'), 
                    'dark'  => __('Dark', 'wyde-core'),                    
                );
                foreach($options as $value => $text):
                ?>
                <option value="<?php echo esc_attr($value); ?>"<?php echo ($instance['theme'] == $value) ? ' selected="selected"' : '';?>><?php echo esc_html($text); ?></option>
                <?php  endforeach; ?>
            </select>        
        </p>

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php echo esc_html__('Number of tweets', 'wyde-core'); ?>:</label>
		    <input id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="text" value="<?php echo intval( $instance['count'] ); ?>" size="3" />
        </p> 

        <div>
            <label for="<?php echo esc_attr( $this->get_field_id('width') ); ?>"><?php echo esc_html__('Width', 'wyde-core'); ?>:</label>
            <input class="widefat" type="text" style="width: 50px;" id="<?php echo esc_attr( $this->get_field_id('width') ); ?>" name="<?php echo esc_attr( $this->get_field_name('width') ); ?>" value="<?php echo esc_attr( $instance['width'] ); ?>" />
            <p><?php echo esc_html__('Set the box width, or leave it blank to use auto width.', 'wyde-core'); ?></p>
        </div>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('height') ); ?>"><?php echo esc_html__('Height', 'wyde-core'); ?>:</label>
            <input class="widefat" type="text" style="width: 50px;" id="<?php echo esc_attr( $this->get_field_id('height') ); ?>" name="<?php echo esc_attr( $this->get_field_name('height') ); ?>" value="<?php echo esc_attr( $instance['height'] ); ?>" />
        </p>
            
<?php
	}
}
add_action('widgets_init', 'wyde_widget_twitter_load');

function wyde_widget_twitter_load()
{
	register_widget('Wyde_Widget_Twitter');
}