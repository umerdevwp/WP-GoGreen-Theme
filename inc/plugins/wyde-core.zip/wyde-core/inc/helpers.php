<?php 

/** Theme Options panel **/     
function wyde_include_theme_options(){               
    include_once( WYDE_PLUGIN_DIR .'inc/redux-framework/framework.php' );
}

/** Metaboxes **/
function wyde_include_metabox(){    
    include_once( WYDE_PLUGIN_DIR .'inc/metabox/class-wyde-metabox.php' );  
}

/** Wyde Importer **/
function wyde_include_importer(){           
    include_once( WYDE_PLUGIN_DIR .'inc/importer/class-wyde-importer.php' );
}

/** Wyde Ajax Search **/
function wyde_include_ajax_search(){         
    include_once( WYDE_PLUGIN_DIR .'inc/class-wyde-ajax-search.php' );      
}

/** Wyde Mega Menu class **/
function wyde_include_mega_menu(){           
    include_once( WYDE_PLUGIN_DIR .'inc/megamenu/class-wyde-mega-menu.php' );
}

/** Wyde Breadcrumb **/
function wyde_include_breadcrumb(){          
    include_once( WYDE_PLUGIN_DIR .'inc/class-wyde-breadcrumb.php' );   
}

/** Wyde Shortcodes **/ 
function wyde_include_shortcode(){                  
    include_once( WYDE_PLUGIN_DIR .'shortcodes/class-wyde-shortcode.php' );
}

/** Wyde Widgets **/ 
function wyde_include_widget(){                  
    include_once( WYDE_PLUGIN_DIR .'widgets/class-wyde-widget.php' );
}

/** Load Font Icons from css file **/
function wyde_get_font_icons_from_css( $css_file ) {

    $css = '';
    if( !empty($css_file) ){
        ob_start();
        include $css_file;
        $css = ob_get_clean();
    }

    $icons = array();
    $hex_codes = array();

    preg_match_all( '/\.(icon-|fa-)([^,}]*)\s*:before\s*{\s*(content:)\s*"(\\\\[^"]+)"/s', $css, $matches );
    $icons = $matches[2];
    $hex_codes = $matches[4];

    $icons = array_combine( $hex_codes, $icons );

    asort( $icons );

    return $icons;

}

/** Get font icons from caches **/
function wyde_get_font_icons( $name, $version = 1.0, $css_file){
    $cache_version = get_transient( $name.'_current_version' );
    $icons = get_transient( $name.'_icons' );
    if($cache_version == false || $cache_version < $version || $icons == false){
        $icons = wyde_get_font_icons_from_css( $css_file );
        set_transient( $name.'_icons', $icons, 4 * WEEK_IN_SECONDS );
        set_transient( $name.'_current_version', $version, 4 * WEEK_IN_SECONDS );
    }
    return $icons;
}

/**
 * Locate a template and return the path for inclusion.
 */
function wyde_locate_template( $slug, $name = '' ) {

    $template = '';

    if ( $name ) {
        $template = locate_template( "{$slug}-{$name}.php" );
    }

    // If template file doesn't exist, look in yourtheme/slug.php and yourtheme/woocommerce/slug.php
    if ( ! $template ) {
        $template = locate_template( "{$slug}.php" );
    } 

    return $template;
}

/**
 * Get content template file, passing attributes and including the file.
 */
function wyde_get_template( $slug, $name, $args = array() ) {    

    $template_file = wyde_locate_template( $slug, $name );

    if ( ! empty( $args ) && is_array( $args ) ) {
        extract( $args );
    }

    if ( $template_file && file_exists( $template_file ) ) {
        include( $template_file );
    }
}