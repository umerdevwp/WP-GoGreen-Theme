<?php
/**
 * This class handles the Breadcrumbs generation and display
 */
class Wyde_Breadcrumb {

	/**
	 * @var    object    Instance of this class
	 */
	public static $instance;

	/**
	 * @var    string    Blog's show on front setting, 'page' or 'posts'
	 */
	private $show_on_front;

	/**
	 * @var mixed    Current post object
	 */
	private $post;

	/**
	 * @var    array   Options array
	 */
	private $options;


	/**
	 * @var string    HTML wrapper element for a single breadcrumb element
	 */
	private $element = 'span';

	/**
	 * @var string    Breadcrumb separator
	 */
	private $separator = '/';

	/**
	 * @var string    HTML wrapper element for the breadcrumbs output
	 */
	private $wrapper = 'div';


	/**
	 * @var    array    Array of crumbs
	 *
	 * Each element of the crumbs array can either have one of these keys:
	 *    "id"         for post types;
	 *    "ptarchive"  for a post type archive;
	 *    "term"       for a taxonomy term.
	 * OR it consists of a predefined set of 'text', 'url' and 'allow_html'
	 */
	private $crumbs = array();

	/**
	 * @var array    Count of the elements in the $crumbs property
	 */
	private $crumb_count = 0;

	/**
	 * @var array    Array of individual (linked) html strings created from crumbs
	 */
	private $links = array();

	/**
	 * @var    string    Breadcrumb html string
	 */
	private $output;


	/**
	 * Create the breadcrumb
	 */
	public function __construct( $options = array() ) {

		$defaults = array(			
			'home'				=> 'Home',	
			'home_url'			=> home_url(),			
			'archive_prefix'	=> '',
			'search_prefix'		=> 'Search Results for',
			'404_prefix'		=> 'Page not found',
			'separator'			=> '/',
			'product_term'		=> 'product_cat',
			'portfolio_term'	=> 'portfolio_category',
			'allow_duplicate'	=> true,
		);
 
   		$this->options = wp_parse_args( $options, $defaults );

		$this->separator = '<span class="w-breadcrumb-sep">'.$this->options['separator'].'</span>';

		$this->post           = ( isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null );
		$this->show_on_front  = get_option( 'show_on_front' );	
			
	}

	/**
	 * Add root crumbs
	 *
	 */
	private function add_root_crumbs(){
		
		$this->add_home_crumb();
		$this->add_blog_crumb_to_post();
		
		$root_crumbs = array();
		$root_crumbs = apply_filters('wyde_breadcrumb_post_root', $root_crumbs);

		foreach ($root_crumbs as $crumb ) {
			$this->add_single_post_crumb( $crumb );
		}

		do_action('wyde_breadcrumb_add_root');

	}

	private function add_child_crumbs(){
		$this->set_crumbs();
		$this->prepare_links();
		$this->links_to_string();
		$this->wrap_breadcrumb();
	}

	/**
	 * Get breadcrumb string using the singleton instance of this class
	 *
	 * @param bool   $display Echo or return flag.
	 *
	 * @return object
	 */
	public static function breadcrumb( $options = array(), $display = true ) {
		if ( ! ( self::$instance instanceof self ) ) {
			self::$instance = new self( $options );
		}

		do_action('wyde_breadcrumb_before_generate');

		self::$instance->add_root_crumbs();

		self::$instance->add_child_crumbs();		

		$output = self::$instance->output;

		if ( $display === true ) {
			echo $output;

			return true;
		}
		else {
			return $output;
		}
	}

	/**
	 * Add a single id based crumb to the crumbs property
	 *
	 * @param int $id Post ID.
	 */
	public function add_single_post_crumb( $id ) {

		if( $this->options['allow_duplicate'] === false ){
			if( array_search($id, array_column($this->crumbs, 'id') ) !== false ){
				return;
			}
		}		

		$this->crumbs[] = array(
			'id' => $id,
		);
	}

	/**
	 * Retrieve the hierachical ancestors for the current 'post'
	 *
	 * @return array
	 */
	private function get_post_ancestors() {
		$ancestors = array();

		if ( isset( $this->post->ancestors ) ) {
			if ( is_array( $this->post->ancestors ) ) {
				$ancestors = array_values( $this->post->ancestors );
			}
			else {
				$ancestors = array( $this->post->ancestors );
			}
		}
		elseif ( isset( $this->post->post_parent ) ) {
			$ancestors = array( $this->post->post_parent );
		}

		/**
		 * Filter: Allow changing the ancestors for the breadcrumbs output
		 *
		 * @api array $ancestors Ancestors
		 */
		$ancestors = apply_filters( 'wyde_breadcrumb_ancestors', $ancestors );

		if ( ! is_array( $ancestors ) ) {
			trigger_error( 'The return value for the "wyde_breadcrumb_ancestors" filter should be an array.', E_USER_WARNING );
			$ancestors = (array) $ancestors;
		}

		// Reverse the order so it's oldest to newest.
		$ancestors = array_reverse( $ancestors );

		return $ancestors;
	}

	/**
	 * Determine the crumbs which should form the breadcrumb.
	 */
	private function set_crumbs() {
		/** @var WP_Query $wp_query */
		global $wp_query;			

		if ( ( $this->show_on_front === 'page' && is_front_page() ) || ( $this->show_on_front === 'posts' && is_home() ) ) {
			// Do nothing.
		}
		elseif ( $this->show_on_front == 'page' && is_home() ) {
			$this->add_blog_crumb();
		}
		elseif ( is_singular() ) {

			if ( isset( $this->post->post_parent ) && 0 == $this->post->post_parent ) {
				$this->add_taxonomy_crumbs_for_post();
			}
			else {
				$this->add_post_ancestor_crumbs();
			}		

			if ( isset( $this->post->ID ) ) {
				$this->add_single_post_crumb( $this->post->ID );
			}
		}
		else {
			if ( is_post_type_archive() ) {
				$post_type = $wp_query->get( 'post_type' );

				if ( $post_type && is_string( $post_type ) ) {
					$this->add_post_type_archive_crumb( $post_type );
				}
			}
			elseif ( is_tax() || is_tag() || is_category() ) {
				$this->add_crumbs_for_taxonomy();
			}
			elseif ( is_date() ) {
				if ( is_day() ) {
					$this->add_linked_month_year_crumb();
					$this->add_date_crumb();
				}
				elseif ( is_month() ) {
					$this->add_month_crumb();
				}
				elseif ( is_year() ) {
					$this->add_year_crumb();
				}
			}
			elseif ( is_author() ) {
				$user = $wp_query->get_queried_object();
				$this->add_predefined_crumb(
					$this->options['archive_prefix'] . $user->display_name,
					null,
					true
				);
			}
			elseif ( is_search() ) {
				$this->add_predefined_crumb(
					$this->options['search_prefix'] . '"' . esc_html( get_search_query() ) . '"',
					null,
					true
				);
			}
			elseif ( is_404() ) {
				$this->add_predefined_crumb(
					$this->options['404_prefix'],
					null,
					true
				);
			}
		}

		/**
		 * Filter: 'wyde_breadcrumb_links' - Allow the developer to filter the breadcrumb links, add to them, change order, etc.
		 *
		 * @api array $crumbs The crumbs array
		 */
		$this->crumbs = apply_filters( 'wyde_breadcrumb_links', $this->crumbs );

		$this->crumb_count = count( $this->crumbs );
	}


	/**
	 * Add a term based crumb to the crumbs property
	 *
	 * @param object $term Term data object.
	 */
	private function add_term_crumb( $term ) {
		$this->crumbs[] = array(
			'term' => $term,
		);
	}

	/**
	 * Add a post type archive based crumb to the crumbs property
	 *
	 * @param string $post_type Post type.
	 */
	private function add_post_type_archive_crumb( $post_type ) {
		$this->crumbs[] = array(
			'ptarchive' => $post_type,
		);
	}

	/**
	 * Add a predefined crumb to the crumbs property
	 *
	 * @param string $text       Text string.
	 * @param string $url        URL string.
	 * @param bool   $allow_html Flag to allow HTML.
	 */
	private function add_predefined_crumb( $text, $url = '', $allow_html = false ) {
		$this->crumbs[] = array(
			'text'       => $text,
			'url'        => $url,
			'allow_html' => $allow_html,
		);
	}

	/**
	 * Add Homepage crumb to the crumbs property
	 */
	private function add_home_crumb() {

		if( $this->options['home'] !== false ){

			if( $this->show_on_front === 'page' ){		

				$home_id = get_option( 'page_on_front' );			

				$this->add_single_post_crumb( $home_id );	

			}elseif( $this->show_on_front === 'posts' ){

				$this->add_predefined_crumb( $this->options['home'], $this->options['home_url'] );

			}
			
		}		

	}

	/**
	 * Add Blog crumb to the crumbs property for single posts
	 */
	private function add_blog_crumb_to_post() {
		if ( ( 'page' === $this->show_on_front && 'post' === get_post_type() ) && ( ! is_home() && ! is_search() ) ) {
			if ( $this->options['blog'] !== false ) {
				$this->add_blog_crumb();
			}
		}
	}

	/**
	 * Add Blog crumb to the crumbs property
	 */
	private function add_blog_crumb() {
		$this->add_single_post_crumb( $this->options['blog'] );
	}

	/**
	 * Add hierarchical ancestor crumbs to the crumbs property for a single post
	 */
	private function add_post_ancestor_crumbs() {
		$ancestors = $this->get_post_ancestors();
		if ( is_array( $ancestors ) && $ancestors !== array() ) {
			foreach ( $ancestors as $ancestor ) {
				$this->add_single_post_crumb( $ancestor );
			}
		}
	}

	/**
	 * Add taxonomy crumbs to the crumbs property for a single post
	 */
	private function add_taxonomy_crumbs_for_post() {

		if ( isset( $this->post->ID ) ) {

			$taxonomy = 'category';

			switch ( $this->post->post_type ) {
				case 'wyde_portfolio':
					$taxonomy = $this->options['portfolio_term'];
					break;
				case 'product':
					$taxonomy = $this->options['product_term'];
					break;				
			}
			
			$terms = get_the_terms( $this->post, $taxonomy );

			if ( is_array( $terms ) && $terms !== array() ) {
				
				$term = $this->get_primary_term( $this->post->ID, $taxonomy );				

				if ( is_taxonomy_hierarchical( $taxonomy ) && $term->parent != 0 ) {
					$parent_terms = $this->get_term_parents( $term );
					foreach ( $parent_terms as $parent_term ) {
						$this->add_term_crumb( $parent_term );
					}
				}

				$this->add_term_crumb( $term );
			}
		}
		
	}

	private function get_primary_term( $post_id, $taxonomy ){
		$terms = get_the_terms( $post_id, $taxonomy ); 
	    $primary_term = false;
	    if( is_array($terms) && count($terms) > 0 ){
	       $primary_term = $terms[0];	        
	    }
	    return $primary_term;
	}

	/**
	 * Add parent taxonomy crumbs to the crumb property for hierachical taxonomy
	 *
	 * @param object $term Term data object.
	 */
	private function maybe_add_term_parent_crumbs( $term ) {
		if ( is_taxonomy_hierarchical( $term->taxonomy ) && $term->parent != 0 ) {
			foreach ( $this->get_term_parents( $term ) as $parent_term ) {
				$this->add_term_crumb( $parent_term );
			}
		}
	}

	/**
	 * Add taxonomy parent crumbs to the crumbs property for a taxonomy
	 */
	private function add_crumbs_for_taxonomy() {
		$term = $GLOBALS['wp_query']->get_queried_object();

		$this->add_term_crumb( $term );
	}


	/**
	 * Add month-year crumb to crumbs property
	 */
	private function add_linked_month_year_crumb() {
		$this->add_predefined_crumb(
			$GLOBALS['wp_locale']->get_month( get_query_var( 'monthnum' ) ) . ' ' . get_query_var( 'year' ),
			get_month_link( get_query_var( 'year' ), get_query_var( 'monthnum' ) )
		);
	}

	/**
	 * Add (non-link) month crumb to crumbs property
	 */
	private function add_month_crumb() {
		$this->add_predefined_crumb(
			$this->options['archive_prefix'] . ' ' . esc_html( single_month_title( ' ', false ) ),
			null,
			true
		);
	}

	/**
	 * Add (non-link) year crumb to crumbs property
	 */
	private function add_year_crumb() {
		$this->add_predefined_crumb(
			$this->options['archive_prefix'] . ' ' . esc_html( get_query_var( 'year' ) ),
			null,
			true
		);
	}

	/**
	 * Add (non-link) date crumb to crumbs property
	 *
	 * @param string $date Optional date string, defaults to post's date.
	 */
	private function add_date_crumb( $date = null ) {
		if ( is_null( $date ) ) {
			$date = get_the_date();
		}
		else {
			$date = mysql2date( get_option( 'date_format' ), $date, true );
			$date = apply_filters( 'get_the_date', $date, '' );
		}

		$this->add_predefined_crumb(
			$this->options['archive_prefix'] . ' ' . esc_html( $date ),
			null,
			true
		);
	}


	/**
	 * Take the crumbs array and convert each crumb to a single breadcrumb string.
	 *
	 * @link http://support.google.com/webmasters/bin/answer.py?hl=en&answer=185417 Google documentation on RDFA
	 */
	private function prepare_links() {
		if ( ! is_array( $this->crumbs ) || $this->crumbs === array() ) {
			return;
		}

		foreach ( $this->crumbs as $i => $crumb ) {
			$link_info = $crumb; // Keep pre-set url/text combis.

			if ( isset( $crumb['id'] ) ) {
				$link_info = $this->get_link_info_for_id( $crumb['id'] );
			}
			if ( isset( $crumb['term'] ) ) {
				$link_info = $this->get_link_info_for_term( $crumb['term'] );
			}
			if ( isset( $crumb['ptarchive'] ) ) {
				$link_info = $this->get_link_info_for_ptarchive( $crumb['ptarchive'] );
			}

			$this->links[] = $this->crumb_to_link( $link_info, $i );
		}
	}

	/**
	 * Retrieve link url and text based on post id
	 *
	 * @param int $id Post ID.
	 *
	 * @return array Array of link text and url
	 */
	private function get_link_info_for_id( $id ) {
		$link = array();
		$link['url']  = get_permalink( $id );
		$link['text'] = strip_tags( get_the_title( $id ) );	
		$link['text'] = apply_filters( 'wyde_breadcrumb_link_title', $link['text'], $id );

		return $link;
	}

	/**
	 * Retrieve link url and text based on term object
	 *
	 * @param object $term Term object.
	 *
	 * @return array Array of link text and url
	 */
	private function get_link_info_for_term( $term ) {
		$link = array();
		$link['url']  = get_term_link( $term );
		$link['text'] = $term->name;

		return $link;
	}

	/**
	 * Retrieve link url and text based on post type
	 *
	 * @param string $post_type Post type.
	 *
	 * @return array Array of link text and url
	 */
	private function get_link_info_for_ptarchive( $post_type ) {
		$link          = array();
		$archive_title = '';

		$post_type_obj = get_post_type_object( $post_type );
		if ( is_object( $post_type_obj ) ) {
			if ( isset( $post_type_obj->label ) && $post_type_obj->label !== '' ) {
				$archive_title = $post_type_obj->label;
			}
			elseif ( isset( $post_type_obj->labels->menu_name ) && $post_type_obj->labels->menu_name !== '' ) {
				$archive_title = $post_type_obj->labels->menu_name;
			}
			else {
				$archive_title = $post_type_obj->name;
			}
		}
		

		$link['url']  = get_post_type_archive_link( $post_type );
		$link['text'] = $archive_title;

		return $link;
	}


	/**
	 * Create a breadcrumb element string
	 *
	 * @todo The `$paged` variable only works for archives, not for paged articles, so this does not work
	 * for paged article at this moment.
	 *
	 * @param  array $link Link info array containing the keys:
	 *                     'text'    => (string) link text
	 *                     'url'    => (string) link url
	 *                     (optional) 'title'         => (string) link title attribute text
	 *                     (optional) 'allow_html'    => (bool) whether to (not) escape html in the link text
	 * @param  int   $i    Index for the current breadcrumb.
	 *
	 * @return string
	 */
	private function crumb_to_link( $link, $i ) {

		$link_output = '';

		if ( isset( $link['text'] ) && ( is_string( $link['text'] ) && $link['text'] !== '' ) ) {

			$link['text'] = trim( $link['text'] );
			if ( ! isset( $link['allow_html'] ) || $link['allow_html'] !== true ) {
				$link['text'] = esc_html( $link['text'] );
			}

			$inner_elm = 'span';

			if ( ( isset( $link['url'] ) && ( is_string( $link['url'] ) && $link['url'] !== '' ) ) &&
			     ( $i < ( $this->crumb_count - 1 ) )
			) {
				if ( $i === 0 ) {
					$link_output .= '<' . $this->element . ' typeof="v:Breadcrumb">';
				}
				else {
					$link_output .= '<' . $this->element . ' rel="v:child" typeof="v:Breadcrumb">';
				}
				$title_attr   = isset( $link['title'] ) ? ' title="' . esc_attr( $link['title'] ) . '"' : '';
				$link_output .= '<a href="' . esc_url( $link['url'] ) . '" rel="v:url" property="v:title"' . $title_attr . '>' . $link['text'] . '</a>';
			}
			else {
				$link_output .= '<' . $inner_elm . ' class="w-breadcrumb-current">' . $link['text'] . '</' . $inner_elm . '>';
				// This is the last element, now close all previous elements.
				while ( $i > 0 ) {
					$link_output .= '</' . $this->element . '>';
					$i--;
				}
			}
		}

		return apply_filters( 'wyde_breadcrumb_single_link', $link_output, $link );
	}


	/**
	 * Create a complete breadcrumb string from an array of breadcrumb element strings
	 */
	private function links_to_string() {
		if ( is_array( $this->links ) && $this->links !== array() ) {
			// Remove any effectively empty links.
			$links = array_map( 'trim', $this->links );
			$links = array_filter( $links );

			$this->output = implode( $this->separator, $links );
		}
	}

	/**
	 * Wrap a complete breadcrumb string in a Breadcrumb RDFA wrapper
	 */
	private function wrap_breadcrumb() {
		if ( $this->output !== '' ) {

			$output = '<' . $this->wrapper .' class="w-wrapper" xmlns:v="http://rdf.data-vocabulary.org/#">' . $this->output . '</' . $this->wrapper . '>';

			$output = apply_filters( 'wyde_breadcrumb_output', $output );

			$this->output = $output;

		}
	}

}